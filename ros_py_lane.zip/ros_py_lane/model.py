#! /usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "WangXiaolong"
# Date: 2018/8/11


import cv2
import numpy as np
import scipy.signal as signal


fit_prev_left = []
fit_prev_right = []
fit_sum_left = 0
fit_sum_right = 0


def Plot_line(binary_warped):
    histogram = np.sum(binary_warped[1:, :], axis=0)
    #histogram = np.sum(binary_warped[binary_warped.shape[0] // 2:, :], axis=0)
    midpoint = np.int(histogram.shape[0] / 2)
    leftx_base = np.argmax(histogram[:midpoint])
    rightx_base = np.argmax(histogram[midpoint:]) + midpoint

    #jizhi_y= histogram[signal.argrelextrema(histogram[midpoint:], np.greater)]
    #jizhi_x= signal.argrelextrema(histogram[midpoint:], np.greater)
    #if jizhi_x is not None:
     #   rightx_base=jizhi_x[0]+ midpoint

    #lane_width为左右线起点的像素宽度
    lane_width = abs(rightx_base - leftx_base)
    nwindows = 10
    window_height = np.int(binary_warped.shape[0] / nwindows)
    nonzero = binary_warped.nonzero()
    nonzeroy = np.array(nonzero[0])
    nonzerox = np.array(nonzero[1])

    leftx_current = leftx_base
    rightx_current = rightx_base

    margin = 20
    # Set minimum number of pixels found to recenter window
    minpix = 50
    # Create empty lists to receive left and right lane pixel indices
    left_lane_inds = []
    right_lane_inds = []

    # Step through the windows one by one
    for window in range(nwindows):
        # Identify window boundaries in x and y (and right and left)
        win_y_low = binary_warped.shape[0] - (window + 1) * window_height
        win_y_high = binary_warped.shape[0] - window * window_height
        win_xleft_low = leftx_current - margin
        win_xleft_high = leftx_current + margin
        win_xright_low = rightx_current - margin
        win_xright_high = rightx_current + margin
        #在可视化图像上绘制滑动窗口
        #识别窗口内x和y中的非零像素
        good_left_inds = ((nonzeroy >= win_y_low) & (nonzeroy < win_y_high) &
                          (nonzerox >= win_xleft_low) & (nonzerox < win_xleft_high)).nonzero()[0]
        good_right_inds = ((nonzeroy >= win_y_low) & (nonzeroy < win_y_high) &
                           (nonzerox >= win_xright_low) & (nonzerox < win_xright_high)).nonzero()[0]
        #将这些索引附加到列表中,加到后面,默认为水平拼接
        left_lane_inds.append(good_left_inds)
        right_lane_inds.append(good_right_inds)
        #如果发现> minpix像素，则在其平均位置上最近显示下一个窗口
        if len(good_left_inds) > minpix:
            leftx_current = np.int(np.mean(nonzerox[good_left_inds]))
        if len(good_right_inds) > minpix:
            rightx_current = np.int(np.mean(nonzerox[good_right_inds]))

    #连接索引数组，所有滑动窗里面的像素点坐标放在一起
    left_lane_inds = np.concatenate(left_lane_inds)
    right_lane_inds = np.concatenate(right_lane_inds)

    #提取左右行像素位置
    leftx = nonzerox[left_lane_inds]
    lefty = nonzeroy[left_lane_inds]
    rightx = nonzerox[right_lane_inds]
    righty = nonzeroy[right_lane_inds]
    flag =True
    if (leftx.size < 10) or (lefty.size < 10) or (rightx.size < 10) or (righty.size < 10):
        flag=False

        warp_zero = np.zeros_like(binary_warped).astype(np.uint8)
        color_warp1=np.dstack((warp_zero, warp_zero, warp_zero))

        left_fit1=[1,1,1]
        right_fit1=[1,1,1]

        return flag , color_warp1, left_fit1, right_fit1, left_lane_inds, right_lane_inds, lane_width

    #将二阶多项式拟合到每个,left_fit和right-fit是二阶多向式的系数，且v轴为x，u轴为y拟合的多项式
    left_fit = np.polyfit(lefty, leftx, 2)
    right_fit = np.polyfit(righty, rightx, 2)

    #求出y像素坐标，带入到曲线方程中求出左右曲线的各个像素点的x坐标
    ploty = np.linspace(0, binary_warped.shape[0] - 1, binary_warped.shape[0])
    left_fitx = left_fit[0] * ploty ** 2 + left_fit[1] * ploty + left_fit[2]
    right_fitx = right_fit[0] * ploty ** 2 + right_fit[1] * ploty + right_fit[2]
    warp_zero = np.zeros_like(binary_warped).astype(np.uint8)
    color_warp = np.dstack((warp_zero, warp_zero, warp_zero))
    cv2.imshow('color_warp',color_warp)

    # Recast the x and y points into usable format for cv2.fillPoly()
    pts_left = np.array([np.transpose(np.vstack([left_fitx, ploty]))])
    pts_right = np.array([np.flipud(np.transpose(np.vstack([right_fitx, ploty])))])
    pts = np.hstack((pts_left, pts_right))

    # Draw the lane onto the warped blank image
    cv2.fillPoly(color_warp, np.int_([pts]), (0, 255, 0))
    cv2.polylines(color_warp, np.int32([pts_left]), isClosed=False, color=(0, 0, 255), thickness=8)
    cv2.polylines(color_warp, np.int32([pts_right]), isClosed=False, color=(0, 0, 255), thickness=8)

    return flag,color_warp, left_fit, right_fit, left_lane_inds, right_lane_inds, lane_width
