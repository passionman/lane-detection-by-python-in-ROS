#!/usr/bin/env python
# -*- coding: utf-8 -*-
import rospy
from geometry_msgs.msg import PoseArray
import cv2
import numpy as np
import process_img
import threshold
import model
import calculate
import display


def Lane_pipeline(img, width, height):
    # 获得感兴趣区域的图片
    cut_img = process_img.roi(img, width, height)
    cv2.imshow('cut_img', cut_img)
    M, M_inv = process_img.get_m_minv(width, height)

    trans_img = process_img.transform(cut_img, M)
    cv2.imshow('trans_img', trans_img)

    '''
    h_hls, l_hls, s_hls = threshold.hls_channel_converter(trans_img)
    binary_1_ = threshold.channel_threshold(s_hls, (155, 255))
    #binary_1_ = threshold.channel_threshold(l_hls, (190, 255))
    cv2.imshow('l_hls', binary_1_)

    l_luv, u_luv, v_luv = threshold.luv_channel_converter(trans_img)

    binary_2_ = threshold.channel_threshold(l_luv, (170, 255))
    cv2.imshow('l_luv', binary_2_)

    l_lab, a_lab, b_lab = threshold.lab_channel_converter(trans_img)
    #但是udacity用的是b通道（0,255）
    binary_3_ = threshold.channel_threshold(l_lab, (190, 255))
    #YCrCb色彩空间里面把三个通道提取出来
    cv2.imshow('l_lab', binary_3_)
    y_ycrcb, cr_ycrcb, cb_ycrcb = threshold.ycrcb_channel_converter(trans_img)
    #Y通道(190,255)
    binary_4_ = threshold.channel_threshold(y_ycrcb, (190, 255))
    cv2.imshow('y_ycrcb', binary_4_)
    #RGB色彩空间里面把三个通道提取出来
    r_rgb, g_rgb, b_rgb = threshold.rgb_channel_converter(trans_img)
    #r通道(180,255)
    binary_5_ = threshold.channel_threshold(r_rgb, (180, 255))
    cv2.imshow('r_rgb', binary_5_ )

    combine1_binary = np.zeros_like(binary_1_)
    combine1_binary[(binary_5_ == 1) | (binary_1_ == 1) | (binary_2_ == 1)] = 1
    #cv2.imshow('yanseyuzhi_combine1', combine1_binary)

    #binary_1 = threshold.abs_sobel_thresh(trans_img, orient='x', thresh_min=40, thresh_max=255)
    binary_1 = threshold.abs_sobel_thresh(trans_img, orient='x', thresh_min=10, thresh_max=230)#这个阈值不行

    binary_2 = threshold.dir_threshold(trans_img, sobel_kernel=3, thresh=(0.7, 1.3))#uda原版阈值(0.7,1.3)
    #binary_2 = threshold.dir_threshold(trans_img, sobel_kernel=3, thresh=(0.7, 1.1))#uda改后阈值(0.7,1.1)

    binary_3 = threshold.mag_thresh(trans_img, sobel_kernel=3, mag_thresh=(80, 255))#这个阈值不行
    #binary_4 = threshold.sobel_image(trans_img, orient='x', thresh_min=50, thresh_max=255, convert=True)
    #binary_5 = threshold.sobel_gradient_image(trans_img, thresh=(1.2, 1.8), convert=True)
    #binary_6 = threshold.sobel_mag(trans_img, (40, 255), convert=True)

    combine2_binary = np.zeros_like(binary_1)
    combine2_binary[(binary_1 == 1) | (binary_2 == 1) | (binary_3 == 1)] = 1#这里可以改
    cv2.imshow('com2',combine2_binary)
    #将梯度阈值和颜色阈值合并
    combine_binary = np.zeros_like(binary_5_)
    combine_binary[(combine1_binary == 1) & (combine2_binary == 1)] = 1
    cv2.imshow('com1+2', combine_binary)
    '''

    h_hls, l_hls, s_hls = threshold.hls_channel_converter(trans_img)
    binary_hls = threshold.channel_threshold(s_hls, (155, 255))
    cv2.imshow('l_hls', binary_hls)

    l_luv, u_luv, v_luv = threshold.luv_channel_converter(trans_img)
    binary_luv = threshold.channel_threshold(l_luv, (170, 255))
    cv2.imshow('l_luv', binary_luv)

    l_lab, a_lab, b_lab = threshold.lab_channel_converter(trans_img)
    # 但是udacity用的是b通道（0,255）
    binary_lab = threshold.channel_threshold(b_lab, (155, 200))
    cv2.imshow('l_lab', binary_lab)

    binary_abs_sobel_x = threshold.abs_sobel_thresh(trans_img, orient='x', thresh_min=10, thresh_max=230)  # 这个阈值不行
    binary_dir_thresh = threshold.dir_threshold(trans_img, sobel_kernel=3, thresh=(0.7, 1.3))  # uda原版阈值(0.7,1.3)
    binary_mag_thresh = threshold.mag_thresh(trans_img, sobel_kernel=3, mag_thresh=(30, 150))  # 这个阈值不行

    combine_binary = np.zeros_like(binary_luv)
    combine_binary[
        ((binary_abs_sobel_x == 1) & (binary_mag_thresh == 1)) | ((binary_dir_thresh == 1) & (binary_hls == 1)) | (
                    binary_lab == 1) | (binary_luv == 1)] = 1
    cv2.imshow('com1+2', combine_binary)

    flag, color_warp, left_fit, right_fit, left_lane_inds, right_lane_inds, lane_width = model.Plot_line(combine_binary)
    if flag == False:
        laneImage1 = cut_img
        return laneImage1
    curverad, center_dist, width_lane, lane_center_position, center_wpoints_x2, center_wpoints_y2 = calculate.calc_radius_position(
        combine_binary, left_fit, right_fit, left_lane_inds, right_lane_inds, lane_width)

    unwarped_image = process_img.reverse_warping(color_warp, M_inv)

    laneImage = cv2.addWeighted(cut_img, 0.8, unwarped_image, 0.2, 0)

    laneImage = display.Plot_details(laneImage, curverad, center_dist, width_lane, lane_center_position)

    return laneImage, center_wpoints_x2, center_wpoints_y2



def points_publisher():

    rospy.init_node('points_publisher', anonymous=True)

    points_pub = rospy.Publisher('/campoints', PoseArray, queue_size=10)

    rate = rospy.Rate(10)

    video = cv2.VideoCapture(1)
    width = int(video.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(video.get(cv2.CAP_PROP_FRAME_HEIGHT))

    intrinsic = np.array([[3.5903059000442818e+02, 0, 3.1333491981942166e+02],
                          [0, 3.5757448472996236e+02, 2.1948072287845247e+02],
                          [0, 0, 1]])
    distortion_coe = np.array([-3.5362482344775037e-01, 1.6536918724701943e-01,
                               2.0070619793076693e-03, -5.1822437394115155e-04,
                               -4.4640643414784090e-02])
    while not rospy.is_shutdown():
        ret, frame_dis = video.read()
        frame_dis = cv2.undistort(frame_dis, intrinsic, distortion_coe, None, intrinsic)
        cv2.imshow('cap', frame_dis)
        frame_ok, center_wpoints_x_all, center_wpoints_y_all = Lane_pipeline(frame_dis, width, height)
        cv2.imshow('frame_ok', frame_ok)
        cv2.waitKey(27)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
        points_msg = PoseArray()

        for i in range(8)
            points_msg.position.x = center_wpoints_x_all[i]
            points_msg.position.y = center_wpoints_y_all[i]

        points_pub.publish(points_msg)
        #rospy.loginfo("Publish campoints [%0.2f m, %0.2f m]",points_msg.position.x, points_msg.position.y)

        rate.sleep()

    video.release()
    cv2.destroyAllWindows()

if __name__ == '__main__':
    try:
        points_publisher()
    except rospy.ROSInterruptException:
        pass

