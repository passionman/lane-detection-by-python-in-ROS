#! /usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "WangXiaolong"
# Date: 2018/8/11

import cv2
import numpy as np


def roi(src ,w ,h):

    #h1 = int(0.5*h)
    #h2 = int(0.98*h)
    #w1 = int(0.03*w)
    #w2 = int(0.97*w)
    #roi_img = src[h1 : h2 , w1 : w2]
    #roi_img = src[220:375, 40:600]

    roi_img = src[0: h, 0: w]
    return roi_img


def get_m_minv(w,h):
    #这是戒掉窗口后的点坐标
    #src = np.float32([[(208,5), (308,5), (435,153), (80,153)]])
    #dst = np.float32([[(140,0), (375,0), (375,154), (140,154)]])

    src = np.float32([[(248, 225), (348,225), (475, 373), (120, 373)]])
    dst = np.float32([[(120,20), (475, 20), (475, 480), (120,480)]])
    m = cv2.getPerspectiveTransform(src, dst)
    m_inv = cv2.getPerspectiveTransform(dst, src)
    return m, m_inv


def transform(img, m):
    wrap_img = cv2.warpPerspective(img, m, img.shape[1::-1], flags=cv2.INTER_LINEAR)
    return wrap_img


def reverse_warping(img,M):
    un_warp = cv2.warpPerspective(img, M, img.shape[1::-1], flags=cv2.INTER_LINEAR)
    return un_warp

def gray_edge(img):

    blurred = cv2.GaussianBlur(img, (3, 3), 0)
    gray = cv2.cvtColor(blurred, cv2.COLOR_RGB2GRAY)
    xgrad = cv2.Sobel(gray, cv2.CV_16SC1, 1, 0)
    ygrad = cv2.Sobel(gray, cv2.CV_16SC1, 0, 1)
    edge_output = cv2.Canny(xgrad, ygrad, 50, 150)
    canny = cv2.Canny(gray, 100, 200)

    return blurred, gray, edge_output, canny




